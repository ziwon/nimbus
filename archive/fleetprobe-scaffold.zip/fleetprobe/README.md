# fleetprobe

A small Zig project for experimenting with one codebase across edge devices, servers, and cloud containers.

`fleetprobe` builds a portable agent/control-plane binary. The same executable can:

- inspect the local target and print a heartbeat as JSON;
- send that heartbeat to an HTTP endpoint;
- run a tiny in-memory HTTP control plane.

This is intentionally a toy project. The first goal is to exercise Zig's cross-compilation and build system without introducing third-party dependencies. For v0.1, HTTPS support is disabled at compile time to keep cross-builds fast and the edge binaries small; place a TLS-terminating proxy in front of the server when needed.

## Architecture

```text
Raspberry Pi / Jetson / mini PC       Server or cloud container
┌──────────────────────────────┐      ┌─────────────────────────────┐
│ fleetprobe send              │ HTTP │ fleetprobe serve            │
│ linux-aarch64 / linux-x86_64 ├─────►│ POST /v1/heartbeat          │
└──────────────────────────────┘      │ GET  /v1/agents             │
                                      └─────────────────────────────┘

Developer laptop
┌──────────────────────────────┐
│ zig build release            │
│ Linux / Windows / macOS      │
│ x86_64 / aarch64             │
└──────────────────────────────┘
```

## Requirements

- Zig 0.16.0

You can also install the official redistributed toolchain through Python:

```bash
python -m pip install ziglang==0.16.0
python -m ziglang version
```

Replace `zig` below with `python -m ziglang` when using the Python distribution.

## Run locally

```bash
zig build test
zig build run -- inspect --id dev-laptop --role edge
```

Start the control plane:

```bash
zig build run -- serve --bind 127.0.0.1 --port 8080
```

From another terminal:

```bash
zig build run -- send \
  --endpoint http://127.0.0.1:8080/v1/heartbeat \
  --id edge-01 \
  --role edge

curl http://127.0.0.1:8080/v1/agents
```

## Cross-compile

```bash
zig build release
```

Artifacts are written to:

```text
zig-out/releases/linux-x86_64/fleetprobe
zig-out/releases/linux-aarch64/fleetprobe
zig-out/releases/windows-x86_64/fleetprobe.exe
zig-out/releases/macos-x86_64/fleetprobe
zig-out/releases/macos-aarch64/fleetprobe
```

The Linux builds use musl, making them suitable for small containers and many edge distributions.

## Container build

```bash
docker build -t fleetprobe .
docker run --rm -p 8080:8080 fleetprobe
```

With BuildKit, `TARGETARCH=amd64` and `TARGETARCH=arm64` map to Zig's x86_64 and aarch64 Linux targets, so the compiler performs the architecture conversion without executing foreign binaries.

## Current limitations

- only the latest heartbeat is retained;
- the HTTP server is sequential;
- plain HTTP only; HTTPS is disabled in the v0.1 binary and should terminate at a proxy;
- no authentication;
- heartbeat validation only checks that the body looks like a JSON object;
- `send` is one-shot rather than a long-running daemon.

See [PLANNING.md](PLANNING.md) for the next useful milestones.
