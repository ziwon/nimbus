const std = @import("std");
const Io = std.Io;

const max_heartbeat_bytes = 64 * 1024;
const json_header = [_]std.http.Header{
    .{ .name = "content-type", .value = "application/json" },
};

const State = struct {
    last_heartbeat: std.ArrayList(u8) = .empty,

    fn deinit(state: *State, allocator: std.mem.Allocator) void {
        state.last_heartbeat.deinit(allocator);
    }

    fn replace(state: *State, allocator: std.mem.Allocator, body: []const u8) !void {
        state.last_heartbeat.clearRetainingCapacity();
        try state.last_heartbeat.appendSlice(allocator, body);
    }
};

pub fn serve(init: std.process.Init, bind_address: []const u8, port: u16) !void {
    const address = try Io.net.IpAddress.parse(bind_address, port);
    var listener = try address.listen(init.io, .{ .reuse_address = true });
    defer listener.deinit(init.io);

    const notice = try std.fmt.allocPrint(
        init.gpa,
        "fleetprobe server listening on http://{s}:{d}\n",
        .{ bind_address, listener.socket.address.getPort() },
    );
    defer init.gpa.free(notice);
    try Io.File.stderr().writeStreamingAll(init.io, notice);

    var state: State = .{};
    defer state.deinit(init.gpa);

    while (true) {
        const stream = try listener.accept(init.io);
        handleConnection(init, &state, stream) catch |err| {
            const message = try std.fmt.allocPrint(init.gpa, "request failed: {t}\n", .{err});
            defer init.gpa.free(message);
            Io.File.stderr().writeStreamingAll(init.io, message) catch {};
        };
    }
}

fn handleConnection(init: std.process.Init, state: *State, stream: Io.net.Stream) !void {
    defer stream.close(init.io);

    var recv_buffer: [8192]u8 = undefined;
    var send_buffer: [8192]u8 = undefined;
    var conn_reader = stream.reader(init.io, &recv_buffer);
    var conn_writer = stream.writer(init.io, &send_buffer);
    var server = std.http.Server.init(&conn_reader.interface, &conn_writer.interface);
    var request = try server.receiveHead();

    if (request.head.method == .GET and std.mem.eql(u8, request.head.target, "/healthz")) {
        return request.respond("{\"status\":\"ok\"}\n", .{
            .keep_alive = false,
            .extra_headers = &json_header,
        });
    }

    if (request.head.method == .POST and std.mem.eql(u8, request.head.target, "/v1/heartbeat")) {
        var body_buffer: [4096]u8 = undefined;
        const body_reader = try request.readerExpectContinue(&body_buffer);
        const body = body_reader.allocRemaining(init.gpa, .limited(max_heartbeat_bytes)) catch |err| switch (err) {
            error.StreamTooLong => {
                return request.respond("{\"error\":\"heartbeat_too_large\"}\n", .{
                    .status = .payload_too_large,
                    .keep_alive = false,
                    .extra_headers = &json_header,
                });
            },
            else => |other| return other,
        };
        defer init.gpa.free(body);

        if (body.len == 0 or body[0] != '{') {
            return request.respond("{\"error\":\"invalid_json_object\"}\n", .{
                .status = .bad_request,
                .keep_alive = false,
                .extra_headers = &json_header,
            });
        }

        try state.replace(init.gpa, body);
        return request.respond("{\"accepted\":true}\n", .{
            .status = .accepted,
            .keep_alive = false,
            .extra_headers = &json_header,
        });
    }

    if (request.head.method == .GET and std.mem.eql(u8, request.head.target, "/v1/agents")) {
        if (state.last_heartbeat.items.len == 0) {
            return request.respond("[]\n", .{
                .keep_alive = false,
                .extra_headers = &json_header,
            });
        }

        const response = try std.fmt.allocPrint(init.gpa, "[{s}]\n", .{state.last_heartbeat.items});
        defer init.gpa.free(response);
        return request.respond(response, .{
            .keep_alive = false,
            .extra_headers = &json_header,
        });
    }

    return request.respond("{\"error\":\"not_found\"}\n", .{
        .status = .not_found,
        .keep_alive = false,
        .extra_headers = &json_header,
    });
}
