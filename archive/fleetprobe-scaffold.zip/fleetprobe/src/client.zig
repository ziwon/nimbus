const std = @import("std");

pub const SendResult = struct {
    status: std.http.Status,
    response_body: []const u8,
};

pub fn sendHeartbeat(
    init: std.process.Init,
    endpoint: []const u8,
    payload: []const u8,
    response_buffer: []u8,
) !SendResult {
    var client: std.http.Client = .{
        .allocator = init.gpa,
        .io = init.io,
    };
    defer client.deinit();

    var response_writer: std.Io.Writer = .fixed(response_buffer);
    const result = try client.fetch(.{
        .location = .{ .url = endpoint },
        .method = .POST,
        .payload = payload,
        .response_writer = &response_writer,
        .keep_alive = false,
        .extra_headers = &.{
            .{ .name = "content-type", .value = "application/json" },
            .{ .name = "accept", .value = "application/json" },
        },
    });

    return .{
        .status = result.status,
        .response_body = response_writer.buffered(),
    };
}
