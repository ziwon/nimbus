const std = @import("std");
const builtin = @import("builtin");
const build_options = @import("build_options");

pub const Heartbeat = struct {
    schema_version: u8 = 1,
    agent_id: []const u8,
    hostname: []const u8,
    role: []const u8,
    os: []const u8,
    arch: []const u8,
    abi: []const u8,
    cpu_count: usize,
    timestamp_unix_ms: i64,
    agent_version: []const u8 = build_options.version,
};

pub fn collect(init: std.process.Init, agent_id: ?[]const u8, role: []const u8) Heartbeat {
    const hostname = init.environ_map.get("HOSTNAME") orelse
        init.environ_map.get("COMPUTERNAME") orelse
        "unknown";

    return .{
        .agent_id = agent_id orelse hostname,
        .hostname = hostname,
        .role = role,
        .os = @tagName(builtin.target.os.tag),
        .arch = @tagName(builtin.target.cpu.arch),
        .abi = @tagName(builtin.target.abi),
        .cpu_count = std.Thread.getCpuCount() catch 0,
        .timestamp_unix_ms = std.Io.Clock.real.now(init.io).toMilliseconds(),
    };
}

pub fn serializeAlloc(allocator: std.mem.Allocator, value: Heartbeat) ![]u8 {
    return std.json.Stringify.valueAlloc(allocator, value, .{});
}

test "heartbeat JSON contains portable target metadata" {
    const value: Heartbeat = .{
        .agent_id = "edge-01",
        .hostname = "raspberrypi",
        .role = "edge",
        .os = "linux",
        .arch = "aarch64",
        .abi = "musl",
        .cpu_count = 4,
        .timestamp_unix_ms = 1_700_000_000_000,
    };

    const json = try serializeAlloc(std.testing.allocator, value);
    defer std.testing.allocator.free(json);

    try std.testing.expect(std.mem.indexOf(u8, json, "\"agent_id\":\"edge-01\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, json, "\"arch\":\"aarch64\"") != null);
}
