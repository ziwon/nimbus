const std = @import("std");
const Io = std.Io;
const build_options = @import("build_options");
const heartbeat = @import("heartbeat.zig");
const client = @import("client.zig");
const server = @import("server.zig");

// MVP transport is plain HTTP. Disabling TLS keeps edge binaries and cross-builds small.
pub const std_options: std.Options = .{ .http_disable_tls = true };

const CommonOptions = struct {
    agent_id: ?[]const u8 = null,
    role: []const u8 = "edge",
};

pub fn main(init: std.process.Init) !void {
    const args = try init.minimal.args.toSlice(init.arena.allocator());
    if (args.len < 2) usageAndExit(init, null);

    const command = args[1];
    if (std.mem.eql(u8, command, "inspect")) {
        const options = parseCommon(init, args[2..]);
        try inspect(init, options);
    } else if (std.mem.eql(u8, command, "send")) {
        try send(init, args[2..]);
    } else if (std.mem.eql(u8, command, "serve")) {
        try runServer(init, args[2..]);
    } else if (std.mem.eql(u8, command, "version") or std.mem.eql(u8, command, "--version")) {
        try Io.File.stdout().writeStreamingAll(init.io, build_options.version ++ "\n");
    } else if (std.mem.eql(u8, command, "help") or std.mem.eql(u8, command, "--help") or std.mem.eql(u8, command, "-h")) {
        usageAndExit(init, null);
    } else {
        usageAndExit(init, "unknown command");
    }
}

fn inspect(init: std.process.Init, options: CommonOptions) !void {
    const value = heartbeat.collect(init, options.agent_id, options.role);
    const payload = try heartbeat.serializeAlloc(init.gpa, value);
    defer init.gpa.free(payload);

    try Io.File.stdout().writeStreamingAll(init.io, payload);
    try Io.File.stdout().writeStreamingAll(init.io, "\n");
}

fn send(init: std.process.Init, args: []const []const u8) !void {
    var options: CommonOptions = .{};
    var endpoint: []const u8 = "http://127.0.0.1:8080/v1/heartbeat";

    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (std.mem.eql(u8, arg, "--id")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--id requires a value");
            options.agent_id = args[i];
        } else if (std.mem.eql(u8, arg, "--role")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--role requires a value");
            options.role = args[i];
        } else if (std.mem.eql(u8, arg, "--endpoint")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--endpoint requires a value");
            endpoint = args[i];
        } else {
            usageAndExit(init, "unknown send option");
        }
    }

    const value = heartbeat.collect(init, options.agent_id, options.role);
    const payload = try heartbeat.serializeAlloc(init.gpa, value);
    defer init.gpa.free(payload);

    var response_buffer: [4096]u8 = undefined;
    const result = try client.sendHeartbeat(init, endpoint, payload, &response_buffer);

    const summary = try std.fmt.allocPrint(init.gpa, "HTTP {d}\n{s}", .{
        @intFromEnum(result.status),
        result.response_body,
    });
    defer init.gpa.free(summary);
    try Io.File.stdout().writeStreamingAll(init.io, summary);
}

fn runServer(init: std.process.Init, args: []const []const u8) !void {
    var bind_address: []const u8 = "127.0.0.1";
    var port: u16 = 8080;

    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (std.mem.eql(u8, arg, "--bind")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--bind requires a value");
            bind_address = args[i];
        } else if (std.mem.eql(u8, arg, "--port")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--port requires a value");
            port = std.fmt.parseInt(u16, args[i], 10) catch usageAndExit(init, "invalid port");
        } else {
            usageAndExit(init, "unknown serve option");
        }
    }

    try server.serve(init, bind_address, port);
}

fn parseCommon(init: std.process.Init, args: []const []const u8) CommonOptions {
    var options: CommonOptions = .{};
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (std.mem.eql(u8, arg, "--id")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--id requires a value");
            options.agent_id = args[i];
        } else if (std.mem.eql(u8, arg, "--role")) {
            i += 1;
            if (i >= args.len) usageAndExit(init, "--role requires a value");
            options.role = args[i];
        } else {
            usageAndExit(init, "unknown inspect option");
        }
    }
    return options;
}

fn usageAndExit(init: std.process.Init, message: ?[]const u8) noreturn {
    if (message) |text| {
        Io.File.stderr().writeStreamingAll(init.io, text) catch {};
        Io.File.stderr().writeStreamingAll(init.io, "\n\n") catch {};
    }

    Io.File.stderr().writeStreamingAll(init.io,
        \\fleetprobe - portable edge/server/cloud heartbeat probe
        \\
        \\Usage:
        \\  fleetprobe inspect [--id ID] [--role edge|server|cloud]
        \\  fleetprobe send [--endpoint URL] [--id ID] [--role ROLE]
        \\  fleetprobe serve [--bind ADDRESS] [--port PORT]
        \\  fleetprobe version
        \\
        \\Endpoints:
        \\  GET  /healthz
        \\  POST /v1/heartbeat
        \\  GET  /v1/agents
        \\
    ) catch {};
    std.process.exit(if (message == null) 0 else 2);
}

test {
    _ = heartbeat;
}
