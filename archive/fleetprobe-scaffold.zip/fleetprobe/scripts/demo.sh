#!/usr/bin/env sh
set -eu

ZIG=${ZIG:-zig}
PORT=${PORT:-18080}

$ZIG build
./zig-out/bin/fleetprobe serve --bind 127.0.0.1 --port "$PORT" &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT INT TERM
sleep 1

./zig-out/bin/fleetprobe send \
  --endpoint "http://127.0.0.1:$PORT/v1/heartbeat" \
  --id demo-edge \
  --role edge

curl -fsS "http://127.0.0.1:$PORT/v1/agents"
