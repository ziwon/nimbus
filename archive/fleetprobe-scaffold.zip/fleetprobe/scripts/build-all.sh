#!/usr/bin/env sh
set -eu

ZIG=${ZIG:-zig}
$ZIG build test
$ZIG build release
find zig-out/releases -type f -maxdepth 2 -print
