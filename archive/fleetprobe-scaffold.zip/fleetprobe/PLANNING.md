# Planning

## Goal

Use Zig where it is strongest: ship one small operational binary from a single source tree to edge, server, desktop, and cloud targets.

## v0.1 — scaffolded

- [x] One executable with `inspect`, `send`, and `serve` modes
- [x] JSON heartbeat containing OS, architecture, ABI, CPU count, role, and timestamp
- [x] Minimal HTTP ingestion and agent listing endpoints
- [x] Linux x86_64/aarch64, Windows x86_64, and macOS x86_64/aarch64 release builds
- [x] Static musl Linux binaries
- [x] Docker and systemd examples
- [x] Unit test and CI workflow

## v0.2 — make it a real edge agent

- [ ] `agent` daemon mode with interval and jitter
- [ ] TOML or JSON configuration file
- [ ] Bearer-token authentication
- [ ] Graceful shutdown and retry with exponential backoff
- [ ] Linux memory, disk, network, container, and GPU probes behind platform-specific modules

## v0.3 — fleet control plane

- [ ] SQLite persistence
- [ ] Multiple agents and stale-agent detection
- [ ] Signed binary manifests and self-update experiment
- [ ] OCI artifact publication for binaries and configuration bundles
- [ ] Kubernetes DaemonSet and Helm chart

## Design constraints

1. Keep the agent dependency-free until a dependency clearly pays for itself.
2. Preserve one source tree; isolate OS-specific behavior behind small modules.
3. Cross-compile in CI rather than emulating target machines.
4. Treat remote command execution and OTA updates as security-sensitive features, not casual additions.
